-------------------------------
--  "Zenburn" awesome theme  --
--    By Adrian C. (anrxc)   --
-------------------------------

-- local themes_path = require("gears.filesystem").get_themes_dir()
local themes_path = "~/.config/awesome/theme/"
local dpi = require("beautiful.xresources").apply_dpi



local theme = {}
theme.wallpaper = themes_path .. "wp1.jpg"
-- }}}

-- {{{ Styles
theme.COLOR_PRIMARY = "#23252E"
theme.COLOR_PRIMARY_ACTIVE = "#424861"
theme.COLOR_PRIMARY_SHELL = "#6600B7"
theme.COLOR_PRIMARY_SHELL_ACTIVE = "#58009C"
theme.COLOR_TEXT_ACTIVE ="#FFFFFF"
theme.COLOR_TEXT_NORMAL ="#FFFFFF80"
theme.COLOR_TEXT_INACTIVE ="#FFFFFF19"
theme.COLOR_TRANSPARENT ="#00000000"
theme.COLOR_TRANSPARENT_50 ="#00000080"
theme.COLOR_TRANSPARENT_10 ="#00000019"
theme.COLOR_TRANSPARENT_25 ="#00000040"
theme.COLOR_TRANSPARENT_5 ="#00000010"
theme.COLOR_RED = "#FF0000"
theme.COLOR_GRADIENT_BLACK_NONE ="linear:0,0,0:32,32,32:0,#00000040:1,#00000000"
theme.COLOR_GRADIENT_BAR = theme.COLOR_TRANSPARENT
-- theme.font      = "overpass nerd font 12" 
theme.font      = "sans 12" 

-- {{{ Colors
theme.fg_normal  = theme.COLOR_TEXT_NORMAL
theme.fg_focus   = theme.COLOR_TEXT_ACTIVE
theme.fg_urgent  = theme.COLOR_RED
theme.bg_normal  = theme.COLOR_PRIMARY
theme.bg_focus   = theme.COLOR_PRIMARY_ACTIVE
theme.bg_urgent  = "#3F3F3F"
theme.bg_systray = theme.bg_normal
-- }}}

-- {{{ Borders
theme.useless_gap   = dpi(4)
theme.border_width  = dpi(0)
-- theme.border_normal = theme.COLOR_PRIMARY
-- theme.border_focus  = theme.COLOR_PRIMARY
-- theme.border_marked = theme.COLOR_PRIMARY
-- }}}

-- {{{ Titlebars
theme.titlebar_bg_focus  = theme.COLOR_TRANSPARENT_5
theme.titlebar_bg_normal = theme.COLOR_TRANSPARENT_5
theme.titlebar_fg_normal = theme.COLOR_TEXT_INACTIVE
-- }}}

-- There are other variable sets
-- overriding the default one when
-- defined, the sets are:
-- [taglist|tasklist]_[bg|fg]_[focus|urgent|occupied|empty|volatile]
-- titlebar_[normal|focus]
-- tooltip_[font|opacity|fg_color|bg_color|border_width|border_color]
-- Example:
--theme.taglist_bg_focus = "#CC9393"
-- }}}
theme.taglist_bg_focus = theme.COLOR_PRIMARY_SHELL_ACTIVE
theme.taglist_fg_urgent = theme.COLOR_TEXT_ACTIVE
theme.taglist_fg_occupied = theme.COLOR_TEXT_ACTIVE
theme.taglist_fg_empty = theme.COLOR_TEXT_ACTIVE
theme.taglist_fg_volatile = theme.COLOR_TEXT_ACTIVE

theme.tasklist_bg_focus = theme.COLOR_PRIMARY_SHELL_ACTIVE
theme.tasklist_bg_normal = theme.COLOR_PRIMARY_SHELL

theme.bg_systray = theme.COLOR_PRIMARY_SHELL
theme.systray_icon_spacing = 1

local gears = require("gears")
theme.tooltip_shape = gears.shape.rounded_rect

theme.prompt_bg = theme.COLOR_PRIMARY_SHELL
theme.prompt_fg = theme.COLOR_TEXT_ACTIVE
-- {{{ Widgets
-- You can add as many variables as
-- you wish and access them by using
-- beautiful.variable in your rc.lua
--theme.fg_widget        = "#AECF96"
--theme.fg_center_widget = "#88A175"
--theme.fg_end_widget    = "#FF5656"
--theme.bg_widget        = "#494B4F"
--theme.border_widget    = "#3F3F3F"
-- }}}

-- {{{ Mouse finder
theme.mouse_finder_color = "#CC9393"
-- mouse_finder_[timeout|animate_timeout|radius|factor]
-- }}}

-- {{{ Menu
-- Variables set for theming the menu:
-- menu_[bg|fg]_[normal|focus]
-- menu_[border_color|border_width]
theme.menu_height = dpi(30)
theme.menu_width  = dpi(200)
theme.menu_bg_focus = theme.COLOR_PRIMARY_ACTIVE
theme.menu_bg_normal = theme.COLOR_PRIMARY
-- }}}

-- {{{ Icons
-- {{{ Taglist
theme.taglist_squares_sel   = themes_path .. "taglist/squarefz.png"
theme.taglist_squares_unsel = themes_path .. "taglist/squarez.png"
--theme.taglist_squares_resize = "false"
-- }}}

-- {{{ Misc
theme.awesome_icon           = themes_path .. "awesome-icon.png"
theme.ubuntu_icon           = themes_path .. "ubuntu-icon-ml.png"
theme.menu_submenu_icon      = themes_path .. "default/submenu.png"
theme.menu_icon = theme.ubuntu_icon
-- }}}

-- {{{ Layout
theme.layout_tile       = themes_path .. "layouts/tile.png"
theme.layout_tileleft   = themes_path .. "layouts/tileleft.png"
theme.layout_tilebottom = themes_path .. "layouts/tilebottom.png"
theme.layout_tiletop    = themes_path .. "layouts/tiletop.png"
theme.layout_fairv      = themes_path .. "layouts/fairv.png"
theme.layout_fairh      = themes_path .. "layouts/fairh.png"
theme.layout_spiral     = themes_path .. "layouts/spiral.png"
theme.layout_dwindle    = themes_path .. "layouts/dwindle.png"
theme.layout_max        = themes_path .. "layouts/max.png"
theme.layout_fullscreen = themes_path .. "layouts/fullscreen.png"
theme.layout_magnifier  = themes_path .. "layouts/magnifier.png"
theme.layout_floating   = themes_path .. "layouts/floating.png"
theme.layout_cornernw   = themes_path .. "layouts/cornernw.png"
theme.layout_cornerne   = themes_path .. "layouts/cornerne.png"
theme.layout_cornersw   = themes_path .. "layouts/cornersw.png"
theme.layout_cornerse   = themes_path .. "layouts/cornerse.png"
-- }}}

-- {{{ Titlebar
theme.titlebar_close_button_focus  = themes_path .. "titlebar/close_focus.png"
theme.titlebar_close_button_normal = themes_path .. "titlebar/close_normal.png"

theme.titlebar_minimize_button_normal = themes_path .. "titlebar/sticky_normal_active.png"
theme.titlebar_minimize_button_focus  = themes_path .. "titlebar/sticky_focus_active.png"

theme.titlebar_ontop_button_focus_active  = themes_path .. "titlebar/ontop_focus_active.png"
theme.titlebar_ontop_button_normal_active = themes_path .. "titlebar/ontop_normal_active.png"
theme.titlebar_ontop_button_focus_inactive  = themes_path .. "titlebar/ontop_focus_inactive.png"
theme.titlebar_ontop_button_normal_inactive = themes_path .. "titlebar/ontop_normal_inactive.png"

theme.titlebar_sticky_button_focus_active  = themes_path .. "titlebar/sticky_focus_active.png"
theme.titlebar_sticky_button_normal_active = themes_path .. "titlebar/sticky_normal_active.png"
theme.titlebar_sticky_button_focus_inactive  = themes_path .. "titlebar/sticky_focus_inactive.png"
theme.titlebar_sticky_button_normal_inactive = themes_path .. "titlebar/sticky_normal_inactive.png"

theme.titlebar_floating_button_focus_active  = themes_path .. "titlebar/floating_focus_active.png"
theme.titlebar_floating_button_normal_active = themes_path .. "titlebar/floating_normal_active.png"
theme.titlebar_floating_button_focus_inactive  = themes_path .. "titlebar/floating_focus_inactive.png"
theme.titlebar_floating_button_normal_inactive = themes_path .. "titlebar/floating_normal_inactive.png"

theme.titlebar_maximized_button_focus_active  = themes_path .. "titlebar/maximized_focus_active.png"
theme.titlebar_maximized_button_normal_active = themes_path .. "titlebar/maximized_normal_active.png"
theme.titlebar_maximized_button_focus_inactive  = themes_path .. "titlebar/maximized_focus_inactive.png"
theme.titlebar_maximized_button_normal_inactive = themes_path .. "titlebar/maximized_normal_inactive.png"
-- }}}
-- }}}

return theme

-- vim: filetype=lua:expandtab:shiftwidth=4:tabstop=8:softtabstop=4:textwidth=80
